class Vremya:
    # def __init__(self, hour, minuta, sekunda):
    def __init__(self):
        pass
            # self.hour = hour
            # self.minuta = minuta
            # self.sekunda = sekunda
#     def tablo(self, hour, minuta, sekunda):
#         print(f'{hour}:{minuta}:{sekunda}')
    
    def hour_make(self, hour:int):
        assert type(hour)==int, 'Только цифры !'
        assert hour >=int(0) and hour <=int(24), 'Значение от 0 до 23'
                
#         return hour
        return ('{:02d}'.format(hour))
    
    def minuta_make(self, minuta:int):
        assert type(minuta)==int, 'Только цифры !'
        assert minuta >=int(0) and minuta <=int(59), 'Значение от 0 до 59'
                
        return ('{:02d}'.format(minuta))
    
    def sekunda_make(self, sekunda:int):
        assert type(sekunda)==int, 'Только цифры !'
        assert sekunda >=int(0) and sekunda <=int(59), 'Значение от 0 до 59'
                
        return ('{:02d}'.format(sekunda))
    
    def tablo(self, hour, minuta, sekunda):
        print(f'{self.hour_make(hour)}:{self.minuta_make(minuta)}:{self.sekunda_make(sekunda)}')       
        
v=Vremya()
v.tablo(3,8,11)    
# v.tablo(3,8,'11')           
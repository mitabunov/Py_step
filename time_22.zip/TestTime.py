import unittest
from TimeMake import Vremya
#Test cases to test Calulator methods
#You always create  a child class derived from unittest.TestCase
class TestTime22(unittest.TestCase):
  #setUp method is overridden from the parent class TestCase
  def setUp(self):
    self.v = Vremya()
  #Each test method starts with the keyword test_
  def test_hour(self):
    self.assertEqual(self.v.hour_make(12),12)
  def test_hour_s(self):
    self.assertEqual(self.v.hour_make(12),'12')
  def test_hour_2(self):
    self.assertEqual(self.v.hour_make(12),120)
  def test_min(self):
    self.assertEqual(self.v.minuta_make(12),12)    
  def test_min_s(self):
    self.assertEqual(self.v.minuta_make(12),'12')
  def test_min_2(self):
    self.assertEqual(self.v.minuta_make(12),120)
  def test_sec(self):
    self.assertEqual(self.v.sekunda_make(12),12)    
  def test_sec_s(self):
    self.assertEqual(self.v.sekunda_make(12),'12')
  def test_sec_2(self):
    self.assertEqual(self.v.sekunda_make(12),120)           

if __name__ == "__main__":
  unittest.main()  

# python TestTime.py -v
    
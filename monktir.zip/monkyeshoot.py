"""
Создать вторую цель, которая умеет делать всё тоже самое, как и первая: появляться в случайных
координатах, реагировать на выстрелы по себе, давать очки, если по ней попали. При желании, картинки,
звуки, музыку можно заменить на что-либо другое.
"""


import random
import sys

import pygame

# pyanimation
def main():
    pygame.init()  # Инициализация всех модулей

    WIDTH = 640
    HEIGHT = 400

    BG_COLOR = (0, 0, 0)

    # Создаём экран
    surface = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Тир по обезьяне')

    # Задаём FPS
    clock = pygame.time.Clock()

    # Задаём цвет прицела
    red = random.randint(70, 255)
    green = random.randint(70, 255)
    blue = random.randint(70, 255)
    linecolor = (red, green, blue)
    x_mouse_pos = 0
    y_mouse_pos = 0
    pygame.mouse.set_visible(False)
    size_scope = 20

    # Обезьяна
    target_image = pygame.image.load('DK.bmp')
    target_rect = target_image.get_rect()  # Вписываем картинку в прямоугольник
    target_rect.x = random.randint(0, WIDTH - target_rect.w)
    target_rect.y = random.randint(0, HEIGHT - target_rect.h)

    target_image2 = pygame.image.load('02bcf44b5898ef640fb4d5fb07763640.gif')
    target_rect2 = target_image2.get_rect()  # Вписываем картинку в прямоугольник
    target_rect2.x = random.randint(0, WIDTH - target_rect2.w)
    target_rect2.y = random.randint(0, HEIGHT - target_rect2.h)

    # Звук выстрела
    shot_sound = pygame.mixer.Sound('shot.wav')
    shot_sound.set_volume(0.05)

    # Музыка
    pygame.mixer.music.load('shot.wav')
    pygame.mixer.music.set_volume(0.0)
    pygame.mixer.music.play(-1)

    # Надпись очков
    score = 0
    font_obj = pygame.font.Font('scootchover-sans.ttf', 24)
    font_color = (120, 120, 120)

    while True:
        # Обработчик событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEMOTION:
                x_mouse_pos, y_mouse_pos = event.pos
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    shot = pygame.Rect(x_mouse_pos, y_mouse_pos, 1, 1)
                    if shot.colliderect(target_rect):
                        target_rect.x = random.randint(0, WIDTH - 48)
                        target_rect.y = random.randint(0, HEIGHT - 32)
                        score += 10
                    if shot.colliderect(target_rect2):
                        target_rect2.x = random.randint(0, WIDTH - 8)
                        target_rect2.y = random.randint(0, HEIGHT - 3)
                        score += 10
                    shot_sound.play()

        # Заливка фона в черный цвет
        surface.fill(BG_COLOR)

        # Отображаем обезьяну
        surface.blit(target_image, target_rect)
        surface.blit(target_image2, target_rect2)


        # Горизонтальная линия
        pygame.draw.line(surface, linecolor, (x_mouse_pos - size_scope, y_mouse_pos), (x_mouse_pos + size_scope, y_mouse_pos), 3)
        # Вертикальная линия
        pygame.draw.line(surface, linecolor, (x_mouse_pos, y_mouse_pos - size_scope), (x_mouse_pos, y_mouse_pos + size_scope), 3)

        # Отображение надписи
        score_text = font_obj.render(f'Score: {score}', True, font_color)
        surface.blit(score_text, (0, 0))

        pygame.display.update()
        clock.tick(60)  # Аналогия FPS (Frame Per Second)


if __name__ == '__main__':
    main()